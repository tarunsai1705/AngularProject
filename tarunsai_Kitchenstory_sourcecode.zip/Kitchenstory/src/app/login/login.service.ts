import { Injectable } from "@angular/core";
@Injectable({
    providedIn:'root',
})
export class Loginservice{
    login:number=0;
}