export class Kitchen{
    fruitID:number;
    fruitName:string;
    fruitSrc:string;
    fruitCategory:string;
    fruitRate:number;
    
}
export class Kitchens{
    constructor(public fruitID="", public fruitName="",public fruitSrc="", public fruitCategory="",public fruitRate=""){

    }
}
