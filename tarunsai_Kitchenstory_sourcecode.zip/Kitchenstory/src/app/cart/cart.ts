export interface Price{
    fruitID:number;
    fruitName:string;
    fruitSrc:string;
    fruitCategory:string;
    fruitRate:number,
    quantity:number;
}