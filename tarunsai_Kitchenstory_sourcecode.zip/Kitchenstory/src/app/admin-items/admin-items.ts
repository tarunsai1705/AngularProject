export interface Kitchen{
    fruitID:number,
    fruitName:string,
    fruitSrc:string,
    fruitCategory:string,
    fruitRate:number
}