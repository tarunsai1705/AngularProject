export class payment{
    constructor(public card="", public expiration="",public cvv="", public postal=""){

    }
}
